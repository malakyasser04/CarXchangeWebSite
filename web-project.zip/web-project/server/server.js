const express = require("express");
const mongoose = require("mongoose");
const userRoutes = require("./routes/userRoutes");
const vehicleRoutes = require("./routes/vehicleRoutes");
const app = express();

mongoose
  .connect(
    "mongodb+srv://Omarelmasry:masry2003@cluster0.zz7nuay.mongodb.net/carXchange2?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => console.log("Database Connected"))
  .catch((error) => console.log("error"));

app.use(express.json());
app.use("/", userRoutes);
app.use("/", vehicleRoutes);

const port = 5000;

app.listen(port, () => console.log("server is running on port 5000"));

const mongoose=require('mongoose');

const userSchema=new mongoose.Schema({
    Username:String,
    EmailAdd1:String,
    Password:String,


})

module.exports = mongoose.model('User', userSchema);

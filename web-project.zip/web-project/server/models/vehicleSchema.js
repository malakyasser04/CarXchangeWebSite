const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema({
    Title: String,
    Make: String,
    Model: String,
    Year: Number,
    Condition: String,
    Transmission: String,
    Mileage: Number,
    FuelType: String,
    Seat: Number,
    EngineCapacity: String,
    Color: String,
    Price: Number,
    Features: String,
    Description: String,
    UserFullName: String,
    UserEmailAdd2: String,
    UserPhoneNumber: String,
    UserLocation: String,
    images: [String],
    owner: {

        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
        }
});

module.exports = mongoose.model('Vehicle', vehicleSchema);

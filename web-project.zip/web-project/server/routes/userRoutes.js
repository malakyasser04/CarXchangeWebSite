const express = require('express');
const Router = express.Router();
const User = require('../models/userSchema.js');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');


const JWT_SECRET = 'SECRET123456'; 

Router.use(
  cors({
    credentials: true,
    origin: 'http://localhost:3000'
  })
);

// User Signup
Router.post('/signup', async (req, res) => {
  try {
    const { Username, EmailAdd1, Password, ConfirmPass } = req.body;

    const existingUser = await User.findOne({ Username });
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" });
    }

    if (Password !== ConfirmPass) {
      return res.status(400).json({ error: "Passwords do not match" });
    }

    const hashedPassword = await bcrypt.hash(Password, 10);

    const user = new User({ Username, EmailAdd1, Password: hashedPassword });
    await user.save();

    res.status(201).json({ message: "Signup successful", user: { Username, EmailAdd1 } });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Server error" });
  }
});

// User Login
Router.post('/login', async (req, res) => {
  try {
    const { Username, Password } = req.body;
    const user = await User.findOne({ Username });

    if (!user) {
      return res.status(400).json({ error: "No user found" });
    }

    const isMatch = await bcrypt.compare(Password, user.Password);
    if (!isMatch) {
      return res.status(400).json({ error: "Incorrect password" });
    }

    const token = jwt.sign({ id: user._id, Username: user.Username }, JWT_SECRET, {
      expiresIn: "1d"
    });

    res.json({ message: "Login successful", token });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Server error" });
  }
});


Router.post('/logout', (req, res) => {
  res.json({ message: "Logged out successfully" });
});

// Middleware to protect routes
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1]; 
  if (!token) return res.status(401).json({ error: "Unauthorized: No token" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: "Invalid token" });
  }
};


Router.get('/profile', authMiddleware, async (req, res) => {
  const user = await User.findById(req.user.id).select("-Password");
  if (!user) {
    return res.status(404).json({ error: "User not found" });
  }
  res.json(user);
});

module.exports = Router;

const express = require("express");
const Router = express.Router();
const Vehicle = require("../models/vehicleSchema.js");
const User = require("../models/userSchema.js");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const jwt = require("jsonwebtoken");

const JWT_SECRET = "SECRET123456";

// Ensure folder exists
const uploadDir = path.join(__dirname, "../../client/public/uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// Multer storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

// CORS middleware
Router.use(
  cors({
    credentials: true,
    origin: "http://localhost:3000",
  })
);

//  Authentication middleware
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Unauthorized: No token" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded; // { id, Username }
    next();
  } catch (err) {
    return res.status(403).json({ error: "Invalid token" });
  }
};

// POST /sell — with authentication and image upload
Router.post(
  "/sell",
  authMiddleware,
  upload.array("images", 15),
  async (req, res) => {
    try {
      const files = req.files;

      if (!files || files.length < 3) {
        files.forEach((file) => fs.unlinkSync(file.path));
        return res
          .status(400)
          .json({ error: "At least 3 images are required." });
      }

      if (files.length > 15) {
        files.slice(15).forEach((file) => fs.unlinkSync(file.path));
      }

      const {
        Title,
        Make,
        Model,
        Year,
        Condition,
        Transmission,
        Mileage,
        FuelType,
        Seat,
        EngineCapacity,
        Color,
        Price,
        Features,
        Description,
        UserFullName,
        UserEmailAdd2,
        UserPhoneNumber,
        UserLocation,
      } = req.body;

      const imageUrls = files.map((file) => `/uploads/${file.filename}`);

      const vehicle = new Vehicle({
        Title,
        Make,
        Model,
        Year,
        Condition,
        Transmission,
        Mileage,
        FuelType,
        Seat,
        EngineCapacity,
        Color,
        Price,
        Features,
        Description,
        UserFullName,
        UserEmailAdd2,
        UserPhoneNumber,
        UserLocation,
        images: imageUrls,
        owner: req.user.id,
      });

      await vehicle.save();
      res
        .status(201)
        .json({ message: "Vehicle posted successfully!", vehicle });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Server error" });
    }
  }
);

//   Get vehicle by id
Router.get("/buy/:id", async (req, res) => {
  try {
    const car = await Vehicle.findById(req.params.id);
    if (!car) return res.status(404).json({ message: "Car not found" });

    res.json(car);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

//  Get all vehicles
Router.get("/buy", async (req, res) => {
  try {
    const cars = await Vehicle.find();
    res.json(cars);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Router.get('/my-vehicles', authMiddleware, async (req, res) => {
//     try {
//         const vehicles = await Vehicle.find({ owner: req.user.id });
//         res.json(vehicles);
//     } catch (error) {
//         res.status(500).json({ error: "Server error" });
//     }
// });

module.exports = Router;

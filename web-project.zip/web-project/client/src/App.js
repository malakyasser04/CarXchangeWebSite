import React from "react";
import LoginSignup from "./components/loginSignup/loginSignup";
import NavBar from "./components/mainPage/NavBar";
import HomePage from "./components/mainPage/HomePage";
import BuyCar from "./components/BuyCar/BuyCar";
import "./App.css";
import SellCar from "./components/SellCar/SellCar";
import ViewDetails from "./components/BuyCar/ViewDetails";
import axios from 'axios'

axios.defaults.baseURL="http://localhost:5000/";
axios.defaults.withCredentials=true;

function App() {
  return (
    <div>
      {/* <NavBar/> */}
      {/* <LoginSignup/> */}
      <HomePage/>
      {/* <BuyCar/> */}
        {/* <SellCar/> */}
        {/* <ViewDetails/> */}
    </div>
  );
}

export default App;

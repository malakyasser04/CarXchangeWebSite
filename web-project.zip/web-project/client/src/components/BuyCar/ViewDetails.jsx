import React, { useEffect, useState } from 'react';
import NavBar from '../mainPage/NavBar';
import FooterH from '../mainPage/FooterH';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLocationDot, faLifeRing, faCarSide, faCalendarDays, faCircleCheck } from '@fortawesome/free-solid-svg-icons';
import Swal from 'sweetalert2';
import Imgview from './Imgview';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function ViewDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [car, setCar] = useState();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);

    const fetchVehicle = async () => {
      try {
        const res = await axios.get("/buy/" + id);
        setCar(res.data);
      } catch (error) {
        console.error("Error fetching vehicles:", error);
      }
    };

    fetchVehicle();
  }, [id]);

  const showSellerInfo = () => {
    if (!isLoggedIn) {
      Swal.fire({
        title: 'Login Required',
        text: 'Please login to view seller information',
        icon: 'info',
        confirmButtonColor: '#fb9551',
        showCancelButton: true,
        confirmButtonText: 'Login',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.isConfirmed) {
          navigate('/login');
        }
      });
      return;
    }

    Swal.fire({
      title: 'Seller Information',
      html: `
        <div style="text-align: left;">
          <p><strong>Name:</strong> ${car?.UserFullName || 'Not provided'}</p>
          <p><strong>Phone:</strong> ${car?.UserPhoneNumber || 'Not provided'}</p>
          <p><strong>Location:</strong> ${car?.UserLocation || 'Not provided'}</p>
          <p><strong>Email:</strong> ${car?.UserEmailAdd2 || 'Not provided'}</p>
        </div>
      `,
      confirmButtonColor: '#fb9551',
      confirmButtonText: 'Close'
    });
  };

  const handleContactSeller = () => {
    if (!isLoggedIn) {
      Swal.fire({
        title: 'Login Required',
        text: 'Please login to contact the seller',
        icon: 'info',
        confirmButtonColor: '#fb9551',
        showCancelButton: true,
        confirmButtonText: 'Login',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.isConfirmed) {
          navigate('/login');
        }
      });
      return;
    }

    if (car?.UserPhoneNumber) {
      window.location.href = `tel:${car.UserPhoneNumber}`;
    } else {
      Swal.fire({
        title: 'Error',
        text: 'Phone number not available',
        icon: 'error',
        confirmButtonColor: '#fb9551'
      });
    }
  };

  return (
    <div>
      <NavBar />
      <div className='grid grid-cols-2 gap-8'>
        <div>
          <div className="relative group flex-1 ml-36 mt-11 mb-9 w-[400] h-[500]">
            {car?.images?.length > 0 ? (
              <Imgview imageUrls={car.images} />
            ) : (
              <div className="flex items-center justify-center h-full bg-gray-100">
                No images available
              </div>
            )}
          </div>

          <div className='ml-36 shadow-xl p-8 rounded-md'>
            <b>Description : </b>{car?.Description}
            <div></div>
          </div>
        </div>

        {/* part2 */}
        <div>
          <div className='mt-9 mr-32 shadow-xl p-4 rounded-md'>
            <div className='flex flex-row justify-between items-center'>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">{car?.Title}</h1>
              <button
                onClick={showSellerInfo}
                className="bg-orange-600 text-white px-4 py-1 rounded-lg font-semibold text-sm hover:bg-orange-700 transition-colors"
              >
                Seller <br /> Information
              </button>
            </div>
            <div className="flex flex-row">
              <div className="bg-orange-500 text-white rounded-lg text-xs mr-4 px-2 flex items-center">{car?.Condition}</div>
              <FontAwesomeIcon icon={faCarSide} size="s" style={{ color: "#e4aa58" }} />
              <div className='text-xs flex items-center mr-4 ml-1 text-gray-600'>{car?.Make}</div>
              <FontAwesomeIcon icon={faLifeRing} style={{ color: "#e4aa58" }} />
              <div className='text-xs flex items-center mr-4 ml-1 text-gray-600'>{car?.Model}</div>
              <FontAwesomeIcon icon={faCalendarDays} style={{ color: "#e4aa58" }} />
              <div className='text-xs flex items-center mr-4 text-gray-600 ml-1'>{car?.Year}</div>
            </div>
            <br />
            <div className='text-3xl font-semibold text-orange-600'>${car?.Price}</div>
            <br />
            <div className='flex'>
              <FontAwesomeIcon icon={faLocationDot} size="lg" style={{ color: "#e4aa58" }} />
              <div className='text-gray-400 ml-2'>{car?.UserLocation}</div>
            </div>
            <br />
            <div className='grid grid-cols-2 gap-4'>
              <div className='bg-gray-100 p-2 rounded-md flex justify-between'>
                <div className='text-gray-500'>Transmission : </div>
                <div>{car?.Transmission}</div>
              </div>
              <div className='flex justify-between bg-gray-100 p-2 rounded-md'>
                <div className='text-gray-500'>Color :</div>
                <div>{car?.Color}</div>
              </div>
              <div className='flex justify-between bg-gray-100 p-2 rounded-md'>
                <div className='text-gray-500'>Seats :</div>
                <div>{car?.Seat}</div>
              </div>
              <div className='flex justify-between bg-gray-100 p-2 rounded-md'>
                <div className='text-gray-500'>Fuel Type :</div>
                <div>{car?.FuelType}</div>
              </div>
              <div className='flex justify-between bg-gray-100 p-2 rounded-md'>
                <div className='text-gray-500'>Mileage :</div>
                <div>{car?.Mileage}</div>
              </div>
              <div className='flex justify-between bg-gray-100 p-2 rounded-md'>
                <div className='text-gray-500'>Engine Capacity :</div>
                <div>{car?.EngineCapacity}</div>
              </div>
            </div>
            <button
              onClick={handleContactSeller}
              className="w-full col-span-2 bg-orange-600 hover:bg-orange-700 text-white py-2 rounded-xl font-semibold mt-4"
            >
              {isLoggedIn ? 'Contact Seller' : 'Login to Contact Seller'}
            </button>
          </div>
          <div className='mt-1 mr-32 shadow-xl p-4 rounded-md'>
            <div className='font-semibold'>Safety Features</div>
            <div className='grid grid-cols-2 gap-4'>
              {car?.Features?.split(',').map((feature, index) => (
                <div key={index}>
                  <FontAwesomeIcon
                    icon={faCircleCheck}
                    className='mr-2'
                    style={{ color: '#fb9551' }}
                  />
                  {feature.trim()}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <FooterH />
    </div>
  );
}
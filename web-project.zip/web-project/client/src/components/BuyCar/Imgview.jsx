import React, { useState } from 'react';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faLocationDot,faArrowRight, faArrowLeft} from '@fortawesome/free-solid-svg-icons';

export default function Imgview({ imageUrls }) {
    const [imageIndex, setImageIndex] = useState(0);

    function nextImage (){
        if (imageIndex < imageUrls.length - 1) {
            setImageIndex(imageIndex + 1);
        }
    };

    function prevImage () {
        if (imageIndex > 0) {
            setImageIndex(imageIndex - 1);
        }
    };

    return (
        <div>
            <img src={imageUrls[imageIndex]} alt='images' style={{ width: '100%', height: 'auto' }}/>
            <div>
                <button className='bottom-0 top-0 absolute block left-0' onClick={prevImage} ><FontAwesomeIcon icon={faArrowLeft} size="xl" style={{color: "#f3a991",}} /></button>
                <button className='bottom-0 top-0 absolute block right-0' onClick={nextImage}><FontAwesomeIcon icon={faArrowRight} size="xl" style={{color: "#f3a991",}} /></button>
            </div>
        </div>
    );
}




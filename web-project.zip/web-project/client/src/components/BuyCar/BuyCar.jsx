import React, { useEffect, useState } from "react";
import NavBar from '../mainPage/NavBar';
import CarCard from '../mainPage/CarCard';
import FooterH from '../mainPage/FooterH';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faArrowLeft} from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';

export default function BuyCar(){
  const [vehicles, setVehicles] = useState([]);
  const [filteredVehicles, setFilteredVehicles] = useState([]);
  const [filters, setFilters] = useState({
    condition: 'all',
    make: '',
    model: '',
    year: '',
  });

  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const res = await axios.get("/buy");
        setVehicles(res.data);
        setFilteredVehicles(res.data); //  filtered vehicles
      } catch (error) {
        console.error("Error fetching vehicles:", error);
      }
    };
    fetchVehicles();
  }, []);

 
  const makes = [...new Set(vehicles.map(car => car.Make))].filter(Boolean);
  const models = [...new Set(vehicles.map(car => car.Model))].filter(Boolean);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };
// filters
  const applyFilters = () => {

    let results = [...vehicles];
    
    if (filters.condition === 'new') {
      results = results.filter(car => car.Condition === 'New');
    } 
    else if (filters.condition === 'used') {
      results = results.filter(car => car.Condition.includes('Used-'));
    }
  
    if (filters.make) {
      results = results.filter(car => car.Make === filters.make);
    }
    

    if (filters.model) {
      results = results.filter(car => car.Model === filters.model);
    }
    

    if (filters.year) {
      results = results.filter(car => car.Year.toString() === filters.year);
    }
    
    setFilteredVehicles(results);
  };

  useEffect(() => {
    applyFilters();
  }, [filters]);

  return(
    <div>
      <NavBar/>
      
      <a href="/">
        <FontAwesomeIcon icon={faArrowLeft} className='fa-2xl ml-4 mt-2 cursor-pointer text-blue-500 fixed hover:text-blue-700' />
      </a>
      
      <div className="flex justify-center shadow-2xl p-10 max-w-3xl mx-auto rounded-lg mt-7 bg-gray-50">
        <div className="grid grid-cols-1 md:grid-cols-7 gap-2 items-center">
          {/* Condition Filter */}
          <div className="flex justify-center">
            <label className="flex items-center">
              <input 
                type="radio" 
                name="condition" 
                value="all" 
                className="mr-1" 
                checked={filters.condition === 'all'}
                onChange={handleFilterChange}
              />
              <span className="cursor-pointer">All</span>
            </label>
          </div>

          <div className="flex justify-center">
            <label className="flex items-center">
              <input 
                type="radio" 
                name="condition" 
                value="new" 
                className="mr-1" 
                checked={filters.condition === 'new'}
                onChange={handleFilterChange}
              />
              <span className="cursor-pointer">New</span>
            </label>
          </div>
          
          <div className="flex justify-center">
            <label className="flex items-center">
              <input 
                type="radio" 
                name="condition" 
                value="used" 
                className="mr-1" 
                checked={filters.condition === 'used'}
                onChange={handleFilterChange}
              />
              <span className="cursor-pointer">Used</span>
            </label>
          </div>
          
          {/* Make Filter */}
          <div className="flex justify-center">
            <select 
              name="make"
              value={filters.make}
              onChange={handleFilterChange}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Make</option>
              {makes.map(make => (
                <option key={make} value={make}>{make}</option>
              ))}
            </select>
          </div>
          
          {/* Model Filter */}
          <div className="flex justify-center">
            <select 
              name="model"
              value={filters.model}
              onChange={handleFilterChange}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Model</option>
              {models.filter(model => 
                !filters.make || vehicles.some(car => car.Make === filters.make && car.Model === model)
              ).map(model => (
                <option key={model} value={model}>{model}</option>
              ))}
            </select>
          </div>

          {/* Year Filter */}
          <div className="flex justify-center">
            <select 
              name="year"
              value={filters.year}
              onChange={handleFilterChange}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Year</option>
              {Array.from({length: 50}, (_, i) => 2025 - i).map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
          
          {/* Reset Button */}
          <div className="flex justify-center">
            <button 
              onClick={() => setFilters({
                condition: 'all',
                make: '',
                model: '',
                year: '',
              })}
              className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
      
      <br /><br />

      <h1 className="text-3xl font-bold mb-6 ml-7">Find your perfect car</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mx-8">
        {filteredVehicles.length > 0 ? (
          filteredVehicles.map((car, index) => (
            <CarCard
              key={car._id}
              car={{
                id: car._id,
                make: car.Make || 'Unknown Make',
                model: car.Model || 'Unknown Model',
                year: car.Year || 'N/A',
                price: car.Price || 0,
                location: car.UserLocation || 'Location not specified',
                mileage: car.Mileage || 'N/A',
                imageUrl: car.images?.[1] || "/fallback.jpg",
              }}
              animationDelay={index * 200}
            />
          ))
        ) : (
          <div className="col-span-3 text-center py-10">
            <p className="text-xl">No cars match your filters</p>
            <button 
              onClick={() => setFilters({
                condition: 'all',
                make: '',
                model: '',
                year: '',
              })}
              className="mt-4 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
      
      <FooterH/>
    </div>
  );
}
import React, { useEffect } from "react";
import "aos/dist/aos.css";
import AOS from "aos";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faDollarSign, faLocationDot,  faCalendar, faGaugeHigh } from '@fortawesome/free-solid-svg-icons';
import { Link } from "react-router-dom";

export default function CarCard  ({ car, animationDelay = 0 }){
    useEffect(() => {
      AOS.init({
        duration: 1000,
        once: true,
        easing: 'ease-in-out',
        mirror: true
      });
    }, []);

  return (
    <div 
      className="rounded-3xl shadow-2xl overflow-hidden w-full max-w-[430px] h-[500px] relative mx-auto" 
      data-aos="fade-up" 
      data-aos-delay={animationDelay}
    >
      <div className="absolute top-3 right-3 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
        <FontAwesomeIcon icon={faDollarSign} className="fa-sm" /> {car.price.toLocaleString()}
      </div>
      
      <img src={car.imageUrl} alt={car.model} className="w-full h-[250px] object-cover" />
      
      <div className="p-4">
        <h3 className="text-xl font-bold text-gray-800">{car.year} {car.make} {car.model}</h3>

        <div className="flex items-center text-yellow-500 my-2">
          
  
        </div>

        <p className="text-gray-600 flex items-center gap-4 text-sm">
          <span className="flex items-center gap-1">
            <FontAwesomeIcon icon={faLocationDot} style={{ color: "#483cec" }} /> 
            {car.location}
          </span>
          <span className="flex items-center gap-1">
            <FontAwesomeIcon icon={faCalendar} style={{ color: "#483cec" }} /> 
            {car.year}
          </span>
        </p>

        <p className="text-gray-600 pt-2 text-sm">
          <FontAwesomeIcon icon={faGaugeHigh} style={{ color: "#483cec" }} /> {car.mileage.toLocaleString()} mi
        </p>

        <div className="flex justify-center">
          <Link to={`/View/${car.id}`}>
          <button 
            className="mt-10 border-transparent bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-500 transition-all duration-300 hover:px-32 border-2 border-black"

          >
            View Details
          </button></Link>
        </div>
      </div>
    </div>
  );
};


import React, { useEffect, useState } from "react";
import "aos/dist/aos.css";
import AOS from "aos";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import CarCard from "./CarCard";
import {faCheck,faHandshake,faFileShield,faUsers,faComment,  faSearch,
  faCommentDots,
  faCar,} from '@fortawesome/free-solid-svg-icons';
import NavBar from "./NavBar";
import FooterH from "./FooterH";
import axios from 'axios';
import ChatBot from "../ChatBot/ChatBot";

export default function HomePage() {

  const [vehicles,setVehicles]=useState([]);


  useEffect(() => {
    AOS.init({ duration: 1000, once: false, easing: 'ease-in-out', mirror: true });

    // Fetch vehicles
    const fetchVehicles = async () => {
      try {
        const res = await axios.get("/buy");
        setVehicles(res.data);
      } catch (error) {
        console.error("Error fetching vehicles:", error);
      }
    };

    fetchVehicles();
  }, []);



  return (
    <div className="bg-gray-50">

      {/* Navbar */}
      <NavBar/>
      <ChatBot/>
      {/* Hero Section */}
      <div className="bg-gradient-to-l from-blue-900 to-blue-500 min-h-screen">
        <section className="pt-12 pb-32 min-h-screen flex items-center text-left relative">
          <div className="w-full px-6 md:px-12 flex">
            <div className="max-w-2xl space-y-6 flex-1" data-aos="fade-right">
              <h1 className="text-4xl font-bold text-white" data-aos="fade-up">
                Find Your Perfect Car <br /> Match
              </h1>
              <p className="text-lg text-blue-100" data-aos="fade-up" data-aos-delay="200">
                Buy and sell cars with confidence on the most trusted automotive <br /> marketplace.
              </p>
              <div className="flex gap-4" data-aos="fade-up" data-aos-delay="400">
                <a href="/Buy">
                <button  className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
                  Buy Car
                </button></a>
                <a href="/Sell"><button className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/10 transition-colors">
                  Sell Car
                </button></a>
              </div>
              
              {/* <div className="flex gap-2 max-w-xl" data-aos="fade-up" data-aos-delay="600">
                <input
                  type="text"
                  placeholder="Search make, model or keyword"
                  className="w-full px-4 py-3 rounded-lg border-0 focus:ring-2 focus:ring-blue-400"
                />
                <button className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-400 transition-colors whitespace-nowrap">
                  Search
                </button>
              </div> */}
            </div>
            <div className="w-[600px] h-[300px] overflow-hidden rounded-lg bg-gray-300 ml-12" data-aos="fade-left">
              <img src="/imglogo3.jpg" alt="Car Showcase" className="w-full h-full object-cover" />
            </div>
          </div>
        </section>
      </div>

      {/* How It Works Section */}
      <section className="py-20 bg-gray-50">
  <div className="max-w-4xl mx-auto px-6 text-center"> {/* Centered container */}
    <h2 className="text-3xl font-bold text-gray-800 mb-6" data-aos="fade-up">
      How CarXchange Works
    </h2>
    <p className="text-gray-600 mb-12 text-lg" data-aos="fade-up" data-aos-delay="200">
      Our simple four-step process makes buying or selling a car quick and hassle-free.
    </p>
    
    <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
      {/* Step 1 */}
      <div className="flex flex-col items-center" data-aos="zoom-in">
        <div className="w-16 h-16 bg-blue-100 text-blue-500 rounded-full flex items-center justify-center mb-4">
          <FontAwesomeIcon icon={faSearch} className="text-2xl" />
        </div>
        <h3 className="font-semibold text-lg mb-2">Browse Real Listings</h3>
        <p className="text-gray-500">See prices from actual owners – no dealer markups </p>
      </div>
      
      {/* Step 2 */}
      <div className="flex flex-col items-center" data-aos="zoom-in" data-aos-delay="200">
        <div className="w-16 h-16 bg-blue-100 text-blue-500 rounded-full flex items-center justify-center mb-4">
          <FontAwesomeIcon icon={faCommentDots} className="text-2xl" />
        </div>
        <h3 className="font-semibold text-lg mb-2">Contact Directly</h3>
        <p className="text-gray-500">Message sellers to arrange test drives </p>
      </div>
          
      {/* Step 3 */}
      <div className="flex flex-col items-center" data-aos="zoom-in" data-aos-delay="600">
        <div className="w-16 h-16 bg-blue-100 text-blue-500 rounded-full flex items-center justify-center mb-4">
          <FontAwesomeIcon icon={faCar} className="text-2xl" flip="horizontal" />
        </div>
        <h3 className="font-semibold text-lg mb-2">Verify the Car</h3>
        <p className="text-gray-500">Inspect the vehicle in person.</p>
      </div>

            {/* Step 4 */}
      <div className="flex flex-col items-center" data-aos="zoom-in" data-aos-delay="400">
        <div className="w-16 h-16 bg-blue-100 text-blue-500 rounded-full flex items-center justify-center mb-4">
          <FontAwesomeIcon icon={faHandshake} className="text-2xl" />
        </div>
        <h3 className="font-semibold text-lg mb-2">Close the Deal</h3>
        <p className="text-gray-500">Negotiate and complete the sale privately </p>
      </div>
      

  
    </div>
  </div>
</section>

      {/* Featured Vehicles Section */}
      <section className="bg-white py-16 w-full">
        <div className="px-6 md:px-12">
          <div className="mb-8" data-aos="fade-up">
            <h2 className="text-3xl font-bold text-gray-900">Featured Vehicles</h2>
            <p className="text-lg text-gray-600">Explore our top picks from thousands of verified listings</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {vehicles.slice(0, 3).map((car, index) => (
        <CarCard
      key={car._id}
      car={{
        id: car._id,
        make: car.Make || 'Unknown Make',
        model: car.Model || 'Unknown Model',
        year: car.Year || 'N/A',
        price: car.Price || 0,
        location: car.UserLocation || 'Location not specified',
        mileage: car.Mileage || 'N/A',
        imageUrl: car.images?.[1] || "/fallback.jpg",
      }}
      animationDelay={index * 200}
    />
  ))}
           
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="section-about" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12" data-aos="fade-up">
            <h2 className="text-3xl font-bold text-gray-800">Why choose CarXchange</h2>
            <p className="text-gray-600 mt-2">We're revolutionizing the car buying and selling experience with these key benefits</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="flex flex-col items-start text-left" data-aos="zoom-in">
              <div className="w-16 h-16 bg-blue-100 text-blue-500 flex items-center justify-center rounded-full mb-4">
                <FontAwesomeIcon icon={faFileShield} className="text-3xl" style={{ color: "#005eff" }} />
              </div>
              <h3 className="font-semibold text-lg">Safe Transactions </h3>
              <p className="text-gray-500 text-sm">Protected messaging and verified seller profiles keep your negotiations secure.</p>
            </div>
            
            <div className="flex flex-col items-start text-left" data-aos="zoom-in" data-aos-delay="200">
              <div className="w-16 h-16 bg-blue-100 text-blue-500 flex items-center justify-center rounded-full mb-4">
                <FontAwesomeIcon icon={faCheck} className="text-3xl" />
              </div>
              <h3 className="font-semibold text-lg">Owner-Verified Listings</h3>
              <p className="text-gray-500 text-sm">Every listing includes real photos, VIN checks, and seller contact details.</p>
            </div>
                
            <div className="flex flex-col items-start text-left" data-aos="zoom-in" data-aos-delay="400">
              <div className="w-16 h-16 bg-blue-100 text-blue-500 flex items-center justify-center rounded-full mb-4">
                <FontAwesomeIcon icon={faUsers} className="text-3xl" style={{ color: "#005eff" }} />
              </div>
              <h3 className="font-semibold text-lg">Direct Owner Sales</h3>
              <p className="text-gray-500 text-sm">Buy straight from owners—no dealership markups or hidden fees.</p>
            </div>
            
            <div className="flex flex-col items-start text-left" data-aos="zoom-in" data-aos-delay="600">
              <div className="w-16 h-16 bg-blue-100 text-blue-500 flex items-center justify-center rounded-full mb-4">
                <FontAwesomeIcon icon={faComment} className="text-3xl" style={{ color: "#005eff" }} />
              </div>
              <h3 className="font-semibold text-lg">Negotiate Directly</h3>
              <p className="text-gray-500 text-sm">Message sellers instantly to discuss pricing and schedule test drives. </p>
            </div>
          </div>
        </div>
      </section>
      <section className="py-16 bg-blue-600" data-aos="fade-up">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold text-white">
          Ready to find your perfect car?
        </h2>
        <p className="mt-4 text-xl text-blue-100 max-w-3xl mx-auto">
          Join thousands of happy customers who bought or sold their cars on
          CarXchange
        </p>
        <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
          <a href="/Buy">
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-medium hover:bg-blue-50 transition">
            Browse Cars
          </button></a>
          <a href="/Sell">
          <button className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-medium hover:bg-white/10 transition">
            Sell Your Car
          </button></a>
        </div>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          <div className="bg-white/10 rounded-lg p-6 backdrop-blur-sm">
            <div className="text-4xl font-bold text-white">10k+</div>
            <p className="mt-2 text-blue-100">Cars sold monthly</p>
          </div>
          <div className="bg-white/10 rounded-lg p-6 backdrop-blur-sm">
            <div className="text-4xl font-bold text-white">98%</div>
            <p className="mt-2 text-blue-100">Customer satisfaction</p>
          </div>
          <div className="bg-white/10 rounded-lg p-6 backdrop-blur-sm">
            <div className="text-4xl font-bold text-white">24/7</div>
            <p className="mt-2 text-blue-100">Customer support</p>
          </div>
        </div>
      </div>
    </section>
      <FooterH/>
      
    </div>
  );
}
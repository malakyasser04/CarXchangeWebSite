import React from "react";



export default function FooterH(){
return(
    <div >
      <footer className="bg-gray-900 text-white p-9">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 ">


        <div>
        <div className="text-xl font-bold text-white">Car <span className="text-orange-500">X</span><span className="text-blue-500">change</span></div><br />

        <p>The most trusted automotive marketplace for buying and selling cars. </p>
      </div>
      <div>
        <h2>Quick Links</h2><br />
        <a href="/"  className="text-gray-400 hover:text-blue-500 transition-colors ">Home</a><br />
        <a href="/Buy"  className="text-gray-400 hover:text-blue-500 transition-colors">Buy</a><br />
        <a href="/Sell"  className="text-gray-400 hover:text-blue-500 transition-colors">Sell</a><br />
        <a href="/#section-about" className="text-gray-400 hover:text-blue-500 transition-colors">About us</a><br />
      </div>
      <div>
      <h2>Support</h2><br />
        <a href="/" className="text-gray-400 hover:text-blue-500 transition-colors">Contact Us</a><br />
        <a href="/Buy" className="text-gray-400 hover:text-blue-500 transition-colors">Terms of Service</a><br />

      </div>
      {/* <div>
      <h2>Newsletter</h2><br />
      <p>Subscribe to our newsletter for the latest updates and offers.</p><br />
      <input type="email" className="bg-gray-600 rounded-l-lg p-1"/>
      <button className="bg-blue-600 p-1 rounded-r-lg hover:bg-blue-700 text-gray-300" >Subscribe</button>

      </div> */}
      

    </div>
    <br />
    <hr className="border-gray-600" />
    <br />
    <div className="flex justify-center text-gray-300">© 2025 CarXchange.All rights reseved.</div>
    </footer>
      </div>

);


}
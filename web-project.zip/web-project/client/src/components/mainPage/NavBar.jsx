import React, { useState, useEffect } from "react";
import { Link, useNavigate } from 'react-router-dom';
import "aos/dist/aos.css";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

export default function NavBar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token);
  }, []);

  const handleLogout = () => {
    // Clear token from localStorage
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    navigate("/login");
  };

  return (
    <div className="bg-white shadow-md w-full sticky top-0 z-50">
      <div className="w-full px-6 md:px-12">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/">
            <div className="text-xl font-bold text-gray-800">
              Car<span className="text-orange-500">X</span>
              <span className="text-blue-500">change</span>
            </div>
          </Link>
          {/* Center Menu */}
          <div className="hidden md:flex space-x-8">
            <Link to="/" className="text-gray-600 hover:text-blue-500 transition-colors">
              Home
            </Link>
            <Link to="/Buy" className="text-gray-600 hover:text-blue-500 transition-colors">
              Buy
            </Link>
            <Link to="/Sell" className="text-gray-600 hover:text-blue-500 transition-colors">
              Sell
            </Link>
            <Link to="/#section-about" className="text-gray-600 hover:text-blue-500 transition-colors">
              About Us
            </Link>
          </div>
          {/* Sign In / Log Out */}
          <div className="flex items-center space-x-2">
            {isLoggedIn ? (
              <>
                <Link to="/profile" className="text-gray-600 hover:text-blue-500 transition-colors mr-4">
                  <FontAwesomeIcon icon={faUser} />
                </Link>
                <button
                  onClick={handleLogout}
                  className="flex items-center text-gray-600 hover:text-red-500 transition-colors"
                >
                  <span>Log Out</span>
                  <FontAwesomeIcon icon={faSignOutAlt} className="ml-2" />
                </button>
              </>
            ) : (
              <Link
                to="/login"
                className="flex items-center text-gray-600 hover:text-blue-500 transition-colors"
              >
                <span>Sign In</span>
                <FontAwesomeIcon icon={faUser} className="ml-2" />
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
import React, { useState, useRef, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import NavBar from '../mainPage/NavBar';
import FooterH from '../mainPage/FooterH';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';

export default function SellCar() {
  const Navigate = useNavigate();
  const [error, setError] = useState("");
  const fileInputRef = useRef(null);
  const [sell, setSell] = useState({
    Title: "",
    Make: "",
    Model: "",
    Year: "",
    Condition: "New",
    Transmission: "automatic",
    Mileage: "",
    FuelType: "",
    Seat: "",
    EngineCapacity: "",
    Color: "",
    Price: "",
    Features: [],
    Description: "",
    UserFullName: "",
    UserEmailAdd2: "",
    UserPhoneNumber: "",
    UserLocation: ""
  });

  // Check if user is logged in when component mounts
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      Swal.fire({
        icon: 'warning',
        title: 'Authentication Required',
        text: 'Please login to sell your car',
        confirmButtonColor: '#3085d6',
      }).then(() => {
        Navigate('/login');
      });
    }
  }, [Navigate]);

  const handleImages = (event) => {
    const files = event.target.files;
    if (files.length < 3) {
      setError("Please select at least 3 images.");
    } else if (files.length > 15) {
      setError("You can upload a maximum of 15 images.");
    } else {
      setError("");
    }
  };

  const handleSell = async (e) => {
    e.preventDefault();
    const files = fileInputRef.current.files;
    
    if (!files || files.length < 3) {
      setError("Please upload at least 3 images.");
      return;
    }

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        await Swal.fire({
          icon: 'error',
          title: 'Authentication Error',
          text: 'Your session has expired. Please login again.',
          confirmButtonColor: '#3085d6',
        });
        Navigate('/login');
        return;
      }

      const formData = new FormData();
      // Append all fields to formData
      Object.keys(sell).forEach(key => {
        if (key === 'Features') {
          formData.append(key, sell[key].join(', '));
        } else {
          formData.append(key, sell[key]);
        }
      });

      // Append each file
      for (let i = 0; i < files.length; i++) {
        formData.append("images", files[i]);
      }

      const res = await axios.post("/sell", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          "Authorization": `Bearer ${token}`
        }
      });

      if (res.data.error) {
        await Swal.fire({
          icon: 'error',
          title: 'Error',
          text: res.data.error,
          confirmButtonColor: '#3085d6',
        });
      } else {
        await Swal.fire({
          icon: 'success',
          title: 'Success!',
          text: 'Vehicle posted successfully!',
          confirmButtonColor: '#3085d6',
        });
        Navigate('/');
      }
    } catch (error) {
      console.error("Error:", error);
      let errorMessage = error.response?.data?.error || error.message;
      
      // Handle token expiration specifically
      if (error.response?.status === 401) {
        errorMessage = "Your session has expired. Please login again.";
        localStorage.removeItem('token');
        Navigate('/login');
      }

      await Swal.fire({
        icon: 'error',
        title: 'Submission Error',
        text: `Error posting vehicle: ${errorMessage}`,
        confirmButtonColor: '#3085d6',
      });
    }
  };

  const handleFeatureChange = (e) => {
    const feature = e.target.name;
    setSell(prev => ({
      ...prev,
      Features: e.target.checked
        ? [...prev.Features, feature]
        : prev.Features.filter(f => f !== feature)
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSell(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className='bg-gray-50'>
      <div className='mb-5'>
        <NavBar/>
      </div>
      <a href="/">
        <FontAwesomeIcon icon={faArrowLeft} className='fa-2xl ml-4 mt-2 cursor-pointer text-blue-500 fixed hover:text-blue-700' />
      </a>
      
      <div className="max-w-4xl mx-auto p-4">
        <h1 className='text-center font-bold text-3xl text-blue-500 mb-2'>Sell Your Car</h1>
        <p className='text-center text-gray-500 mb-8'>Complete the form below to list your car for sale</p>
        
        <form onSubmit={handleSell} className="bg-white rounded-lg shadow-md p-8">
          {/* Car Information Section */}
          <section className="mb-8">
            <h1 className='font-semibold text-xl mb-2'>Car Information</h1>
            <p className="text-gray-600 mb-4">Tell us about your vehicle</p>
            
            <div className="grid grid-cols-1 gap-6">
              {/* Title */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title*</label>
                <input
                  type="text"
                  name="Title"
                  value={sell.Title}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="That will be the title for your Ad"
                  required
                />
              </div>

              {/* Make and Model */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Make*</label>
                  <input
                    name="Make"
                    value={sell.Make}
                    onChange={handleInputChange}
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g. Toyota"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Model*</label>
                  <input
                    name="Model"
                    value={sell.Model}
                    onChange={handleInputChange}
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g. Camry"
                    required
                  />
                </div>
              </div>

              {/* Year, Mileage, Fuel Type */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Year*</label>
                  <input
                    name="Year"
                    value={sell.Year}
                    onChange={handleInputChange}
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g. 2019"
                    min="1900"
                    max={new Date().getFullYear()}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Mileage (miles)</label>
                  <input
                    name="Mileage"
                    value={sell.Mileage}
                    onChange={handleInputChange}
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g. 45000"
                    min="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Fuel Type</label>
                  <select
                    name="FuelType"
                    value={sell.FuelType}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Fuel Type</option>
                    <option value="gasoline">Gasoline</option>
                    <option value="diesel">Diesel</option>
                    <option value="electric">Electric</option>
                    <option value="hybrid">Hybrid</option>
                  </select>
                </div>
              </div>

              {/* Seats, Engine, Color */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Seats*</label>
                  <input
                    name="Seat"
                    value={sell.Seat}
                    onChange={handleInputChange}
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g. 2 or 5"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Engine Capacity*</label>
                  <input
                    name="EngineCapacity"
                    value={sell.EngineCapacity}
                    onChange={handleInputChange}
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g. 1500 CC"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Color*</label>
                  <input
                    name="Color"
                    value={sell.Color}
                    onChange={handleInputChange}
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g. black"
                    required
                  />
                </div>
              </div>

              {/* Condition and Transmission */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Condition*</label>
                  <select
                    name="Condition"
                    value={sell.Condition}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    <option value="New">New</option>
                    <option value="Used-excellent">Used - Excellent</option>
                    <option value="Used-good">Used - Good</option>
                    <option value="Used-fair">Used - Fair</option>
                    <option value="Used-poor">Used - Poor</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Transmission*</label>
                  <select
                    name="Transmission"
                    value={sell.Transmission}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    <option value="automatic">Automatic</option>
                    <option value="manual">Manual</option>
                    <option value="cvt">CVT</option>
                    <option value="semi-automatic">Semi-Automatic</option>
                  </select>
                </div>
              </div>
            </div>
          </section>

          <hr className="border-t border-gray-300 my-6" />

          {/* Features Section */}
          <section className="mb-8">
            <h1 className='font-semibold text-xl mb-2'>Features</h1>
            <p className="text-gray-600 mb-4">Select the features your car has</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {["airConditioning", "powerSteering", "powerWindows", "abs", "airbags", "navigationSystem"].map(feature => (
                <label key={feature} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    name={feature}
                    checked={sell.Features.includes(feature)}
                    onChange={handleFeatureChange}
                    className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                  />
                  <span className="text-gray-700 capitalize">{feature.replace(/([A-Z])/g, ' $1')}</span>
                </label>
              ))}
            </div>
          </section>

          <hr className="border-t border-gray-300 my-6" />

          {/* Price and Images Section */}
          <section className="mb-8">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Asking Price ($)*</label>
              <input
                name="Price"
                value={sell.Price}
                onChange={handleInputChange}
                type="number"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. 15000"
                min="0"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Upload Images* (3-15 images)</label>
              <input
                type="file"
                multiple
                accept="image/*"
                ref={fileInputRef}
                onChange={handleImages}
                className="w-full"
                required
              />
              {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
            </div>
          </section>

          <hr className="border-t border-gray-300 my-6" />

          {/* Description Section */}
          <section className="mb-8">
            <h1 className='font-semibold text-xl mb-2'>Car Description</h1>
            <p className="text-gray-600 mb-4">Tell potential buyers about your car</p>
            <textarea
              name="Description"
              value={sell.Description}
              onChange={handleInputChange}
              placeholder="Describe your car's condition, history, modifications, etc"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-32"
              required
            ></textarea>
          </section>

          <hr className="border-t border-gray-300 my-6" />

          {/* Contact Information Section */}
          <section className="mb-8">
            <h1 className='font-semibold text-xl mb-2'>Contact Information</h1>
            <p className="text-gray-600 mb-4">How buyers can reach you</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className='block text-sm font-medium text-gray-700 mb-1'>Full Name*</label>
                <input
                  name="UserFullName"
                  value={sell.UserFullName}
                  onChange={handleInputChange}
                  type="text"
                  placeholder="Your Full name"
                  className='w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500'
                  required
                />
              </div>
              <div>
                <label className='block text-sm font-medium text-gray-700 mb-1'>Email Address*</label>
                <input
                  name="UserEmailAdd2"
                  value={sell.UserEmailAdd2}
                  onChange={handleInputChange}
                  type="email"
                  placeholder="name@example.com"
                  className='w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500'
                  required
                />
              </div>
              <div>
                <label className='block text-sm font-medium text-gray-700 mb-1'>Phone Number*</label>
                <input
                  name="UserPhoneNumber"
                  value={sell.UserPhoneNumber}
                  onChange={handleInputChange}
                  type="tel"
                  placeholder="(123) 456-7890"
                  className='w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500'
                  required
                />
              </div>
              <div>
                <label className='block text-sm font-medium text-gray-700 mb-1'>Location*</label>
                <input
                  name="UserLocation"
                  value={sell.UserLocation}
                  onChange={handleInputChange}
                  type="text"
                  placeholder="City, State"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
          </section>

          <button
            type='submit'
            className="w-full bg-blue-500 text-white rounded-md p-3 hover:bg-blue-700 transition-colors font-medium"
          >
            Submit Car Listing
          </button>
        </form>
      </div>
      
      <FooterH/>
    </div>
  );
}
import React, { useState } from "react";
import "./loginSignup.css";
import NavBar from "../mainPage/NavBar";
import FooterH from "../mainPage/FooterH";
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';

export default function LoginSignup() {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);

  const [login, setLogin] = useState({
    Username: "",
    Password: ""
  });

  const [signup, setSignup] = useState({
    Username: "",
    EmailAdd1: "",
    Password: "",
    ConfirmPass: ""
  });

  const showSuccessAlert = (message) => {
    Swal.fire({
      icon: 'success',
      title: 'Success!',
      text: message,
      confirmButtonColor: '#3085d6',
      timer: 3000
    });
  };

  const showErrorAlert = (message) => {
    Swal.fire({
      icon: 'error',
      title: 'Error!',
      text: message,
      confirmButtonColor: '#3085d6'
    });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    const { Username, Password } = login;

    try {
      const res = await axios.post("http://localhost:5000/login", {
        Username,
        Password
      });

      if (res.data.error) {
        showErrorAlert(res.data.error);
      } else {
        localStorage.setItem("token", res.data.token);
        setLogin({ Username: "", Password: "" });
        showSuccessAlert(res.data.message);
        navigate('/');
      }
    } catch (error) {
      showErrorAlert("Login error: " + (error.response?.data?.error || error.message));
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    const { Username, EmailAdd1, Password, ConfirmPass } = signup;

    if (Password !== ConfirmPass) {
      showErrorAlert("Passwords don't match!");
      return;
    }

    try {
      const res = await axios.post("http://localhost:5000/signup", {
        Username,
        EmailAdd1,
        Password,
        ConfirmPass
      });

      if (res.data.error) {
        showErrorAlert(res.data.error);
      } else {
        showSuccessAlert("Signup successful! Please login.");
        setIsLogin(true);
        setSignup({ Username: "", EmailAdd1: "", Password: "", ConfirmPass: "" });
      }
    } catch (error) {
      showErrorAlert("Signup error: " + (error.response?.data?.error || error.message));
    }
  };

  return (
    <div>
      <NavBar />
      <div className="container">
        <div className="box1">
          <form className="form">
            <br /><br />
            <h1 className="headerT">{isLogin ? "Welcome Back" : "Create an Account"}</h1>
            <p className="para">
              {isLogin ? (
                <>Don't have an account? <a href="#" className="loginLink" onClick={() => { setIsLogin(false); setLogin({ Username: "", Password: "" }); }}>Sign up for free</a></>
              ) : (
                <>Already have an account? <a href="#" className="signupLink" onClick={() => { setIsLogin(true); setSignup({ Username: "", EmailAdd1: "", Password: "", ConfirmPass: "" }); }}>Log in</a></>
              )}
            </p>
            <div className="conUP"><br /><br />
              <input required value={isLogin ? login.Username : signup.Username} onChange={(event) => {
                const value = event.target.value;
                isLogin ? setLogin({ ...login, Username: value }) : setSignup({ ...signup, Username: value });
              }} className="input" type="text" placeholder=" Username" />

              {!isLogin && (
                <input required value={signup.EmailAdd1} onChange={(event) => {
                  setSignup({ ...signup, EmailAdd1: event.target.value });
                }} className="input" type="email" placeholder=" Email" />
              )}

              <input required value={isLogin ? login.Password : signup.Password} onChange={(event) => {
                const value = event.target.value;
                isLogin ? setLogin({ ...login, Password: value }) : setSignup({ ...signup, Password: value });
              }} className="input" type="password" placeholder=" Password" />

              {!isLogin && (
                <input required value={signup.ConfirmPass} onChange={(event) => {
                  setSignup({ ...signup, ConfirmPass: event.target.value });
                }} className="input" type="password" placeholder=" Confirm password" />
              )}

              {isLogin && (
                <div className="option">
                  {/* <label className="remember"><input type="checkbox" /> Remember me</label>
                  <label className="forgot"><a href="#">Forgot password?</a></label> */}
                </div>
              )}
            </div>
            <div className="button-submit">
              <button className="continuebtn" type="submit" onClick={isLogin ? handleLogin : handleSignup}>Continue &rarr;</button>
            </div>

            {/* <p className="para">Or Continue With</p> */}
          </form>

          {/* <div className="social-buttons">
            <button className="btn-google">Google</button>
            <button className="btn-apple">Apple</button>
          </div> */}
        </div>

        <div className="box2">
          <div className="container2">
            <h1 className="logo">Car<span className="highlight-x">X</span>change</h1>
            <h2 className="subtitle">
              {isLogin ? "The Future of Car Trading is " : "Start Your Journey with Us "}
              <span className="highlight-here">{isLogin ? "Here!" : "Today!"}</span>
            </h2>
            <p className="description">
              {isLogin
                ? "Join thousands of satisfied customers who have found their perfect car match. Start your journey today!"
                : "Create an account and join thousands of satisfied customers who have found their perfect car match."}
            </p>
          </div>
        </div>
      </div>
      <FooterH />
    </div>
  );
}
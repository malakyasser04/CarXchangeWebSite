import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faEnvelope, faPhone, faLocationDot, faCar } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import NavBar from "../mainPage/NavBar";
import FooterH from "../mainPage/FooterH";
// import CarCard from "../mainPage/CarCard"
import { useNavigate } from "react-router-dom";

export default function UserProfile() {
  const [userData, setUserData] = useState(null);
//   const [userVehicles, setUserVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        // Fetch user profile data
        const profileResponse = await axios.get('/profile', {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        setUserData(profileResponse.data);

        setLoading(false);
      } catch (err) {
        setError(err.response?.data?.error || "Failed to fetch data");
        setLoading(false);
        // Redirect to login if unauthorized
        if (err.response?.status === 401) {
          navigate('/login');
        }
      }
    };

    fetchUserData();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-red-500">{error}</div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <NavBar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="bg-blue-600 h-32"></div>
          <div className="px-6 py-4 relative">
            <div className="absolute -top-12 left-6 bg-white p-2 rounded-full shadow-lg">
              <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center">
                <FontAwesomeIcon icon={faUser} className="text-4xl text-gray-500" />
              </div>
            </div>
            <div className="ml-28">
              <h1 className="text-2xl font-bold text-gray-800">{userData?.Username || 'User'}</h1>
            </div>
          </div>
          
          {/* User Info */}
          <div className="px-6 py-4 border-t border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Contact Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center">
                <FontAwesomeIcon icon={faEnvelope} className="text-blue-500 mr-3" />
                <span className="text-gray-700">{userData?.EmailAdd1 || 'Not provided'}</span>
              </div>
              {userData?.EmailAdd2 && (
                <div className="flex items-center">
                  <FontAwesomeIcon icon={faEnvelope} className="text-blue-500 mr-3" />
                  <span className="text-gray-700">{userData.EmailAdd2}</span>
                </div>
              )}
              {userData?.PhoneNumber && (
                <div className="flex items-center">
                  <FontAwesomeIcon icon={faPhone} className="text-blue-500 mr-3" />
                  <span className="text-gray-700">{userData.PhoneNumber}</span>
                </div>
              )}
              {userData?.Location && (
                <div className="flex items-center">
                  <FontAwesomeIcon icon={faLocationDot} className="text-blue-500 mr-3" />
                  <span className="text-gray-700">{userData.Location}</span>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* User's Vehicles */}
        {/* <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-800">
                <FontAwesomeIcon icon={faCar} className="text-blue-500 mr-2" />
                My Vehicles for Sale
              </h2>
              <button 
                onClick={() => navigate('/sell')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg"
              >
                List New Vehicle
              </button>
            </div>
          </div>
          
          {userVehicles.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-gray-500 mb-4">You haven't listed any vehicles yet.</p>
              <button 
                onClick={() => navigate('/sell')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg"
              >
                Sell Your First Car
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
              {userVehicles.map((car) => (
                <CarCard
                  key={car._id}
                  car={{
                    id: car._id,
                    make: car.Make || 'Unknown Make',
                    model: car.Model || 'Unknown Model',
                    year: car.Year || 'N/A',
                    price: car.Price || 0,
                    location: car.UserLocation || 'Location not specified',
                    mileage: car.Mileage || 'N/A',
                    imageUrl: car.images?.[0] || "/fallback.jpg",
                  }}
                />
              ))}
            </div>
          )}
        </div> */}
      </div>
      
      <FooterH />
    </div>
  );
}
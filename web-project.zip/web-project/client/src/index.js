import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import LoginSignup from "./components/loginSignup/loginSignup";
import BuyCar from './components/BuyCar/BuyCar';
import SellCar from './components/SellCar/SellCar';
import ViewDetails from './components/BuyCar/ViewDetails';
import UserProfile from './components/Userinfo/UserProfile';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";

let router = createBrowserRouter([
  {
    path: "/",
    element:<App/>

  },
  {
    path: "login",
    element:<LoginSignup/>

  },
  {
    path: "Buy",
    element:<BuyCar/>

  },
  {
    path: "Sell",
    element:<SellCar/>

  },
  {
    path: "View/:id",
    element:<ViewDetails/>

  },
  {
    path:"profile",
    element:<UserProfile/>
  },
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
<RouterProvider router={router}/>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
